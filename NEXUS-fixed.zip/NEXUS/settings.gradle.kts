pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal(); maven { url = uri("https://maven.rikka.dev/repository/maven-releases/") } } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral(); maven { url = uri("https://maven.rikka.dev/repository/maven-releases/") } } }
rootProject.name = "NEXUS"
include(":app")
