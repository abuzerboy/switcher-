package com.nexus.network.shizuku;

interface IShellService {
    String exec(String command);
}
