package com.nexus.network

/** Conservative policy: never toggles radios by itself in this MVP. */
class SwitchPolicy(
    private val requireValidatedInternet: Boolean = true,
    private val confirmationDelayEvents: Int = 2
) {
    private var consecutiveWifiLosses = 0

    fun evaluate(state: NetworkState): DesiredAction {
        val wifiUsable = state.kind == NetworkKind.WIFI &&
            (!requireValidatedInternet || state.isValidated)

        if (wifiUsable) {
            consecutiveWifiLosses = 0
            return DesiredAction.DISABLE_MOBILE_DATA
        }

        consecutiveWifiLosses++
        return if (consecutiveWifiLosses >= confirmationDelayEvents) {
            DesiredAction.ENABLE_MOBILE_DATA
        } else DesiredAction.NONE
    }
}
