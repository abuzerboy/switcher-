package com.nexus.network

enum class NetworkKind { WIFI, CELLULAR, OTHER, OFFLINE }

data class NetworkState(
    val kind: NetworkKind = NetworkKind.OFFLINE,
    val hasInternet: Boolean = false,
    val isValidated: Boolean = false,
    val detail: String = "Ожидание состояния сети",
    val latencyMs: Long? = null,
    val qualityScore: Float = 0f,
    val probeReachable: Boolean = false
)

enum class DesiredAction { NONE, ENABLE_MOBILE_DATA, DISABLE_MOBILE_DATA }
