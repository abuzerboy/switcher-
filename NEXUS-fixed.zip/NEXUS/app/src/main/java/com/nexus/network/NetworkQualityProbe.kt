package com.nexus.network

import android.net.Network
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max
import kotlin.math.min

/** Measures a tiny HTTPS connectivity-check request through the specific active Network. */
object NetworkQualityProbe {
    fun measure(network: Network): ProbeResult {
        val samples = ArrayList<Long>(3)
        repeat(3) {
            var connection: HttpURLConnection? = null
            try {
                val started = System.nanoTime()
                connection = network.openConnection(URL("https://connectivitycheck.gstatic.com/generate_204")) as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 2500
                connection.readTimeout = 2500
                connection.instanceFollowRedirects = false
                connection.useCaches = false
                val code = connection.responseCode
                val elapsed = (System.nanoTime() - started) / 1_000_000L
                if (code in 200..399) samples += elapsed
            } catch (_: Exception) {
                // A failed probe is reflected in the score; never crash network monitoring.
            } finally {
                connection?.disconnect()
            }
        }
        if (samples.isEmpty()) return ProbeResult(null, 0f, false)
        val latency = samples.sorted()[samples.size / 2]
        // A conservative latency score; validation remains a separate system signal.
        val score = when {
            latency <= 60 -> 1.0f
            latency <= 100 -> .92f
            latency <= 160 -> .82f
            latency <= 250 -> .68f
            latency <= 400 -> .50f
            latency <= 700 -> .30f
            else -> .15f
        }
        val consistency = samples.maxOrNull()!! - samples.minOrNull()!!
        val stabilityPenalty = min(.30f, consistency / 1200f)
        return ProbeResult(latency, max(.05f, score - stabilityPenalty), true)
    }
}

data class ProbeResult(val latencyMs: Long?, val score: Float, val reachable: Boolean)
