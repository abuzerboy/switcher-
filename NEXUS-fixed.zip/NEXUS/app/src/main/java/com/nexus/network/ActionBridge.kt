package com.nexus.network

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.Build
import com.nexus.network.shizuku.IShellService
import rikka.shizuku.Shizuku

interface ActionBridge {
    fun isAvailable(): Boolean
    fun setMobileDataEnabled(enabled: Boolean): Result<Unit>
}

/** Shizuku/ADB bridge. The shell command is best-effort and must be verified on-device. */
class ShizukuActionBridge(private val context: Context) : ActionBridge {
    @Volatile private var remote: IShellService? = null
    @Volatile private var binding = false

    override fun isAvailable(): Boolean = runCatching {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    fun requestPermission(requestCode: Int = 7301) {
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(requestCode)
        }
    }

    fun bind(onResult: (Boolean) -> Unit) {
        if (remote?.asBinder()?.isBinderAlive == true) {
            onResult(true)
            return
        }
        if (!Shizuku.pingBinder() || !isAvailable() || binding) {
            onResult(false)
            return
        }
        binding = true
        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                remote = IShellService.Stub.asInterface(service)
                binding = false
                onResult(remote?.asBinder()?.isBinderAlive == true)
            }
            override fun onServiceDisconnected(name: ComponentName?) {
                remote = null
                binding = false
            }
        }
        try {
            val args = Shizuku.UserServiceArgs(ComponentName(context, ShizukuShellService::class.java))
                .daemon(false)
                .processNameSuffix("nexus_shell")
                .debuggable(BuildConfig.DEBUG)
                .version(1)
            Shizuku.bindUserService(args, connection)
        } catch (_: Throwable) {
            binding = false
            onResult(false)
        }
    }

    override fun setMobileDataEnabled(enabled: Boolean): Result<Unit> = runCatching {
        check(isAvailable()) { "Shizuku не запущен или не выдано разрешение" }
        check(remote?.asBinder()?.isBinderAlive == true) { "Сначала подключи Shizuku UserService" }
        val command = if (enabled) "svc data enable" else "svc data disable"
        val output = remote!!.exec(command)
        check(output.startsWith("EXIT=0")) { "Команда не подтверждена: $output" }
        // A successful shell exit is not proof that the modem state changed on this firmware.
        // Caller/UI must read back the mobile-data state before reporting success.
    }
}

class NoPrivilegeBridge : ActionBridge {
    override fun isAvailable() = false
    override fun setMobileDataEnabled(enabled: Boolean) =
        Result.failure(UnsupportedOperationException("Требуется Shizuku / ADB-разрешение"))
}
