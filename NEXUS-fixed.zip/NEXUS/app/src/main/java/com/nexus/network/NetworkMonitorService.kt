package com.nexus.network

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class NetworkMonitorService : Service() {
    private lateinit var monitor: NetworkMonitor
    private val channelId = "nexus_monitor"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        monitor = NetworkMonitor(this) { state ->
            val networkLabel = when {
                state.kind == NetworkKind.WIFI && state.isValidated -> "Wi-Fi · интернет подтверждён"
                state.kind == NetworkKind.CELLULAR && state.isValidated -> "Мобильная сеть · интернет подтверждён"
                else -> state.detail
            }
            val text = state.latencyMs?.let { "$networkLabel · ${it} мс" } ?: networkLabel
            getSystemService(NotificationManager::class.java).notify(1, notification(text))
        }
        startForeground(1, notification("Мониторинг сети включён"))
        monitor.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        if (::monitor.isInitialized) monitor.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "NEXUS · Мониторинг", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String): Notification {
        val builder: Notification.Builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        builder.setContentTitle("NEXUS")
        builder.setContentText(text)
        builder.setSmallIcon(android.R.drawable.stat_notify_sync)
        builder.setOngoing(true)
        return builder.build()
    }
}
