package com.nexus.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.HandlerThread

class NetworkMonitor(context: Context, private val onChanged: (NetworkState) -> Unit) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val worker = HandlerThread("NEXUS-network-probe").apply { start() }
    private val handler = Handler(worker.looper)
    private var registered = false
    @Volatile private var activeNetwork: Network? = null
    @Volatile private var latest = NetworkState()
    private var probeScheduled = false

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { publish(); scheduleProbe(immediate = true) }
        override fun onLost(network: Network) { publish(); scheduleProbe(immediate = true) }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { publish(); scheduleProbe(immediate = true) }
    }

    fun start() {
        if (registered) return
        cm.registerDefaultNetworkCallback(callback)
        registered = true
        publish()
        scheduleProbe(immediate = true)
    }

    fun stop() {
        if (registered) runCatching { cm.unregisterNetworkCallback(callback) }
        registered = false
        handler.removeCallbacksAndMessages(null)
        worker.quitSafely()
    }

    private fun publish() {
        val network = cm.activeNetwork
        activeNetwork = network
        val caps = network?.let(cm::getNetworkCapabilities)
        val base = when {
            caps == null -> NetworkState()
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkState(
                kind = NetworkKind.WIFI,
                hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),
                isValidated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
                detail = "Wi-Fi подключён"
            )
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkState(
                kind = NetworkKind.CELLULAR,
                hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),
                isValidated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
                detail = "Мобильная сеть"
            )
            else -> NetworkState(
                kind = NetworkKind.OTHER,
                hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),
                isValidated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
                detail = "Другая сеть"
            )
        }
        latest = base.copy(latencyMs = latest.latencyMs, qualityScore = latest.qualityScore, probeReachable = latest.probeReachable)
        onChanged(latest)
    }

    private fun scheduleProbe(immediate: Boolean) {
        if (!registered) return
        if (probeScheduled && !immediate) return
        handler.removeCallbacks(probeRunnable)
        probeScheduled = true
        handler.postDelayed(probeRunnable, if (immediate) 500L else 12_000L)
    }

    private val probeRunnable = object : Runnable {
        override fun run() {
            probeScheduled = false
            val network = activeNetwork
            val base = latest
            if (network == null || !base.isValidated) {
                latest = base.copy(latencyMs = null, qualityScore = 0f, probeReachable = false)
                onChanged(latest)
            } else {
                val result = NetworkQualityProbe.measure(network)
                // Re-check the current network before publishing a result from an older one.
                if (activeNetwork == network) {
                    val score = if (result.reachable) result.score else 0.08f
                    latest = latest.copy(latencyMs = result.latencyMs, qualityScore = score, probeReachable = result.reachable)
                    onChanged(latest)
                }
            }
            scheduleProbe(immediate = false)
        }
    }
}
