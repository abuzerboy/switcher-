package com.nexus.network

import com.nexus.network.shizuku.IShellService
import java.util.concurrent.TimeUnit

/** Runs as the Shizuku shell user (UID 2000), never as root. */
class ShizukuShellService : IShellService.Stub() {
    override fun exec(command: String): String {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val finished = process.waitFor(8, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                return "TIMEOUT"
            }
            val stdout = process.inputStream.bufferedReader().use { it.readText() }
            val stderr = process.errorStream.bufferedReader().use { it.readText() }
            "EXIT=${process.exitValue()}\n$stdout\n$stderr".take(4000)
        } catch (t: Throwable) {
            "ERROR=${t.javaClass.simpleName}:${t.message}"
        }
    }
}
