package com.nexus.network

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.animation.ValueAnimator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Button
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var substatus: TextView
    private lateinit var qualityText: TextView
    private lateinit var wave: QualityWaveView
    private lateinit var monitor: NetworkMonitor
    private lateinit var shizukuBridge: ShizukuActionBridge
    private var latestState = NetworkState()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        shizukuBridge = ShizukuActionBridge(this)

        val root = FrameLayout(this)
        root.addView(FogBackground(this), FrameLayout.LayoutParams(-1, -1))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(30), dp(24), dp(150))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "N E X U S"
            textSize = 25f
            letterSpacing = .12f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        val live = TextView(this).apply {
            text = "●  LIVE"
            textSize = 10f
            letterSpacing = .08f
            setTextColor(Color.rgb(191, 160, 255))
            background = pill(0x332C1D55)
            setPadding(dp(12), dp(7), dp(12), dp(7))
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(live)
        content.addView(header)
        content.addView(label("SMART NETWORK CONTROL", 10f, 0xBFC9C4E8.toInt()).apply {
            letterSpacing = .18f
            setPadding(0, dp(5), 0, dp(24))
        })

        val hero = glassCard().apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(20)) }
        hero.addView(label("ТЕКУЩЕЕ ПОДКЛЮЧЕНИЕ", 10f, 0xB8D7D0F0.toInt()).apply { letterSpacing = .12f })
        status = label("Поиск сети…", 29f, Color.WHITE).apply {
            typeface = android.graphics.Typeface.create("sans-serif-medium", 0)
            setPadding(0, dp(12), 0, dp(2))
        }
        substatus = label("Ожидаем данные от Android", 13f, 0xFFD4CDE8.toInt())
        hero.addView(status)
        hero.addView(substatus)
        hero.addView(divider())
        val foot = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        foot.addView(label("КАЧЕСТВО КАНАЛА", 10f, 0xB8D7D0F0.toInt()), LinearLayout.LayoutParams(0, -2, 1f))
        qualityText = label("ОЦЕНКА · —", 10f, 0xFFE4D6FF.toInt())
        foot.addView(qualityText)
        hero.addView(foot)
        content.addView(hero, marginParams(bottom = 16))

        val automation = glassCard().apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)) }
        automation.addView(label("АВТОМАТИЗАЦИЯ", 11f, 0xFFE9E1FA.toInt()).apply { letterSpacing = .12f })
        automation.addView(settingRow("Домашняя сеть", "Выбор сети добавим в следующем этапе"))
        automation.addView(settingRow("Автопереключение", "Shizuku / ADB · без Root"))
        automation.addView(settingRow("Защита от флаппинга", "Подтверждение потери сети и проверка интернета"))
        val shizukuButton = TextView(this).apply {
            text = "ПРОВЕРИТЬ SHIZUKU  ↗"
            textSize = 11f
            letterSpacing = .06f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = pill(0x447D63C7)
            setPadding(dp(14), dp(13), dp(14), dp(13))
            setOnClickListener {
                try {
                    if (!rikka.shizuku.Shizuku.pingBinder()) {
                        substatus.text = "Запусти Shizuku и Wireless Debugging, затем вернись сюда"
                    } else if (!shizukuBridge.isAvailable()) {
                        shizukuBridge.requestPermission()
                        substatus.text = "Ожидаем разрешение Shizuku"
                    } else {
                        substatus.text = "Подключаем Shizuku…"
                        shizukuBridge.bind { bound ->
                            runOnUiThread {
                                substatus.text = if (bound) "Shizuku подключён · ADB-доступ готов к проверке" else "Shizuku доступен, но UserService не подключился"
                            }
                        }
                    }
                } catch (_: Throwable) {
                    substatus.text = "Shizuku пока недоступен · проверь его запуск и разрешения"
                }
            }
        }
        automation.addView(shizukuButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        content.addView(automation, marginParams(bottom = 16))

        val start = TextView(this).apply {
            text = "ВКЛЮЧИТЬ МОНИТОРИНГ  ↗"
            textSize = 12f
            letterSpacing = .08f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF7555C9.toInt(), 0xFFB65EAA.toInt())).apply { cornerRadius = dp(18).toFloat() }
            setPadding(dp(18), dp(17), dp(18), dp(17))
            setOnClickListener {
                startForegroundService(Intent(this@MainActivity, NetworkMonitorService::class.java))
                substatus.text = "Мониторинг запущен · переключение данных пока не подключено"
                text = "МОНИТОРИНГ АКТИВЕН  ✓"
            }
        }
        content.addView(start, marginParams(bottom = 12))
        content.addView(label("NEXUS работает поверх системного управления сетью Android. Автоматическое управление мобильными данными будет добавлено после проверки Shizuku на ColorOS 16.", 11f, 0xBFC9C4E8.toInt()))

        val scroll = ScrollView(this).apply { clipToPadding = false; isFillViewport = false; addView(content) }
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        wave = QualityWaveView(this)
        val waveParams = FrameLayout.LayoutParams(-1, dp(116), Gravity.BOTTOM)
        root.addView(wave, waveParams)
        setContentView(root)

        monitor = NetworkMonitor(this) { state ->
            runOnUiThread {
                latestState = state
                val name = when (state.kind) {
                    NetworkKind.WIFI -> "Wi-Fi"
                    NetworkKind.CELLULAR -> "Мобильная сеть"
                    NetworkKind.OTHER -> "Другая сеть"
                    NetworkKind.OFFLINE -> "Нет подключения"
                }
                status.text = name
                substatus.text = when {
                    state.isValidated -> "Интернет доступен · соединение подтверждено"
                    state.hasInternet -> "Сеть подключена · интернет не подтверждён"
                    else -> "Ожидание доступного подключения"
                }
                val q = if (state.isValidated && state.probeReachable) state.qualityScore else 0.08f
                wave.quality = q
                val grade = when {
                    q >= .82f -> "ОТЛИЧНО"
                    q >= .65f -> "ХОРОШО"
                    q >= .40f -> "СРЕДНЕЕ"
                    else -> "НЕСТАБИЛЬНО"
                }
                val latency = state.latencyMs?.let { " · ${it} мс" } ?: " · измерение…"
                qualityText.text = grade + latency
            }
        }
        monitor.start()
    }

    override fun onDestroy() {
        if (::monitor.isInitialized) monitor.stop()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(textValue: String, size: Float, color: Int) = TextView(this).apply {
        text = textValue; textSize = size; setTextColor(color)
    }
    private fun pill(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(30).toFloat() }
    private fun glassCard() = LinearLayout(this).apply {
        background = GradientDrawable().apply {
            setColor(0x35FFFFFF)
            cornerRadius = dp(25).toFloat()
            setStroke(dp(1), 0x55FFFFFF)
        }
        elevation = dp(8).toFloat()
    }
    private fun divider() = View(this).apply {
        setBackgroundColor(0x33FFFFFF)
        layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(16); bottomMargin = dp(14) }
    }
    private fun marginParams(bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }
    private fun settingRow(title: String, detail: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, dp(14), 0, dp(4))
        addView(label(title, 14f, Color.WHITE))
        addView(label(detail, 11f, 0xCFCFC6E2.toInt()).apply { setPadding(0, dp(3), 0, 0) })
    }
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }
}

/** Soft violet/pink fog background. */
private class FogBackground(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(13, 10, 25))
        val w = width.toFloat(); val h = height.toFloat()
        paint.shader = RadialGradient(w * .22f, h * .18f, w * .78f,
            intArrayOf(0x887D4CCB.toInt(), 0x337D4CCB, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = RadialGradient(w * .92f, h * .48f, w * .62f,
            intArrayOf(0x557E3F8F, 0x227E3F8F, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = RadialGradient(w * .5f, h * .95f, w * .7f,
            intArrayOf(0x337A5BCB, 0x117A5BCB, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }
}

/** The wave becomes calmer and more regular as the connection score rises. */
private class QualityWaveView(context: android.content.Context) : View(context) {
    var quality: Float = .5f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val animator = ValueAnimator.ofFloat(0f, (2.0 * PI).toFloat()).apply {
        duration = 4200L; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); animator.start() }
    override fun onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val badness = 1f - quality
        val amp = h * (.07f + badness * .20f)
        val frequency = 1.4f + badness * 3.0f
        val speed = .55f + badness * 1.8f
        val base = h * .55f
        val path = Path().apply {
            moveTo(0f, h)
            for (i in 0..120) {
                val x = w * i / 120f
                val t = x / w
                val irregular = if (quality < .45f) sin((t * 17f + phase * 1.7f)) * amp * .20f else 0f
                val y = base + sin(t * frequency * 2f * PI.toFloat() + phase * speed) * amp + irregular
                lineTo(x, y)
            }
            lineTo(w, h); close()
        }
        paint.shader = android.graphics.LinearGradient(0f, base - amp, 0f, h,
            intArrayOf(0x887D5AD8.toInt(), 0x557C4BBE, 0x007C4BBE), null, Shader.TileMode.CLAMP)
        canvas.drawPath(path, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * resources.displayMetrics.density
        paint.color = 0xD8D6B7FF.toInt()
        val line = Path()
        for (i in 0..120) {
            val x = w * i / 120f; val t = x / w
            val y = base + sin(t * frequency * 2f * PI.toFloat() + phase * speed) * amp
            if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
        }
        canvas.drawPath(line, paint)
        paint.style = Paint.Style.FILL
    }
}
