# NEXUS — Android network automation (prototype 0.3.0)

Target device: realme GT 7T / Android 16 / ColorOS 16. No root required.

## Implemented in this prototype
- Kotlin Android app, compile/target SDK 36.
- Active default network monitoring via `ConnectivityManager.NetworkCallback`.
- Distinguishes Wi-Fi, cellular, other and offline states.
- Uses Android's `NET_CAPABILITY_VALIDATED` as the system-level internet validation signal.
- Performs three small HTTPS HEAD probes to Google's 204 connectivity endpoint through the active `Network` every ~12 seconds; median response time and sample spread feed a conservative quality score.
- The violet/pink fog + translucent glass interface has a bottom wave whose motion reacts to the measured quality score.
- Foreground service for user-started continuous monitoring.
- Optional Shizuku API integration and a Shizuku UserService running as shell UID (ADB, UID 2000), not root.
- `svc data enable/disable` is currently an explicit bridge capability only; it is not automatically invoked by the network policy yet.

## Important limitations / safety
- Shizuku must be installed and started by the user through Wireless Debugging. On non-root devices its server normally has to be restarted after reboot.
- ADB/shell privileges vary by Android build. A successful shell exit from `svc data enable/disable` is not proof that the modem setting changed on ColorOS. The actual mobile-data state must be read back and verified on the real GT 7T before enabling automatic switching.
- The app does not turn Wi-Fi on/off. Android should reconnect to saved Wi-Fi networks itself.
- The app does not yet identify/lock a particular home SSID, and does not yet automatically switch mobile data. This is intentional until the device-specific permission and state-readback path is tested.
- HTTPS latency is an indicator, not a full bandwidth test. The probe transfers very little data and may be blocked or delayed by captive portals, DNS filters, VPNs, or carrier policy.
- ColorOS battery management may stop background work. For testing, allow background activity / auto-launch and disable battery optimization for NEXUS and Shizuku if ColorOS offers those controls.
- Android 12+ restricts starting foreground services from the background. Start monitoring from the visible app UI.

## Build
Open this folder in Android Studio with JDK 17. Allow Gradle sync, then Build > Build APK(s).

Dependencies:
- Android Gradle Plugin 8.9.2
- Kotlin 2.1.10
- Shizuku API/provider 13.1.5

## Next device-validation steps
1. Install and start Shizuku via Wireless Debugging.
2. Open NEXUS, tap **ПРОВЕРИТЬ SHIZUKU**, grant its permission.
3. Confirm the UserService binds successfully.
4. Test mobile-data state readback on the GT 7T firmware before wiring any automatic command into `SwitchPolicy`.
5. Add home-network selection by a user-confirmed network identity, debounce timers, cooldowns, and a visible manual override.

## Build APK automatically with GitHub Actions

1. Create a new empty GitHub repository (for example `NEXUS-Android`).
2. Upload/push the **contents** of this project folder to the repository root. Keep `.github/workflows/android.yml` in place.
3. Open the repository's **Actions** tab. The workflow named **Android APK** runs on each push, or can be started with **Run workflow**.
4. When the run finishes, open it and download the `NEXUS-debug-apk` artifact. GitHub stores it for 14 days.
5. To publish an APK under **Releases**, create and push a version tag such as `v0.3.1`. The workflow will attach the debug APK to that release.

The workflow uses JDK 17, Android SDK platform 36, and Gradle 8.11.1. It builds `:app:assembleDebug`.

### Note
This workflow automates compilation; it does not prove device-specific Shizuku commands work. The APK is a debug build and is not a Play Store release. Do not enable automatic mobile-data switching until state changes can be verified on the real device.


## Build APK automatically with GitHub Actions

1. Create a new empty GitHub repository (for example `NEXUS-Android`).
2. Upload/push the **contents** of this project folder to the repository root. Keep `.github/workflows/android.yml` in place.
3. Open the repository's **Actions** tab. The workflow named **Android APK** runs on each push, or can be started with **Run workflow**.
4. When the run finishes, open it and download the `NEXUS-debug-apk` artifact. GitHub stores it for 14 days.
5. To publish an APK under **Releases**, create and push a version tag such as `v0.3.1`. The workflow will attach the debug APK to that release.

The workflow uses JDK 17, Android SDK platform 36, and Gradle 8.11.1. It builds `:app:assembleDebug`.

### Note
This workflow automates compilation; it does not prove device-specific Shizuku commands work. The APK is a debug build and is not a Play Store release. Do not enable automatic mobile-data switching until state changes can be verified on the real device.
